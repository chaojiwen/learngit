/**
  ******************************************************************************
  * @file              : main.c
  * @author            : HZ Zeda Team
  * @version           : V1.0.0.0
  * @date              : 27/09/2014 17:41:56
  * @brief             : c file
  * @description       : Main program body
  ******************************************************************************
  * @attention
  *
  * COPYRIGHT 2014 STMicroelectronics
  *
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MAIN_C
#define MAIN_C

#ifdef __cplusplus
extern "C" {
#endif
//}
/*============================ INCLUDES ======================================*/
//! @name include
//! @{
#include <stdio.h>
#include "stm32f10x.h"
#include "stm32_eval.h"
#include "main.h"
//! @}

#ifdef USE_STM32100B_EVAL
#include "stm32100b_eval_lcd.h"
#elif defined USE_STM3210B_EVAL
#include "stm3210b_eval_lcd.h"
#elif defined USE_STM3210E_EVAL
#include "stm3210e_eval_lcd.h"
#elif defined USE_STM3210C_EVAL
#include "stm3210c_eval_lcd.h"
#elif defined USE_STM32100E_EVAL
#include "stm32100e_eval_lcd.h"
#endif

/*============================ MACRO =========================================*/
#define BSP_GPIOB_CH3					 GPIO_Pin_1
#define BSP_GPIOB_CH4					 GPIO_Pin_0

#define BSP_GPIOF_PWM_GRP				 BSP_GPIOB_CH3 | BSP_GPIOB_CH4

/*============================ TYPES =========================================*/

/*============================ LOCAL VARIABLES ===============================*/
USART_InitTypeDef USART_InitStructure;


/*============================ GLOBAL VARIABLES ==============================*/


/*============================ EXTERN FUNCTIONS ==============================*/
/**
  * @brief  Description "������ʱ����"
  * @param  None
  * @retval None
  */
void delay(int32_t time)
{
    while(time -- );
}

/**
  * @brief  Description "PWM GPIO Init"
  * @param  None
  * @retval None
  */
static  void  BSP_PWM_Init (void)
{
    GPIO_InitTypeDef  gpio_init;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    gpio_init.GPIO_Pin   = BSP_GPIOF_PWM_GRP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    gpio_init.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &gpio_init);
}

/**
  * @brief  Description "������"
  * @param  None
  * @retval None
  */
int CommTask(bool bReturn)
{
    char buf[128];

    buf[0] = 1;
    cpp_env_init((void *)buf, 1);
    return 0;
}

/**
  * @brief  Description "������"
  * @param  None
  * @retval None
  */
int main(void)
{
    /*!< At this stage the microcontroller clock setting is already configured,
         this is done through SystemInit() function which is called from startup
         file (startup_stm32f10x_xx.s) before to branch to application main.
         To reconfigure the default setting of SystemInit() function, refer to
         system_stm32f10x.c file
       */
    GPIO_InitTypeDef GPIOA_InitStructure;

    /* Initialize LEDs, Key Button, LCD and COM port(USART) available on
       STM3210X-EVAL board ******************************************************/
    STM_EVAL_LEDInit(LED1);
    STM_EVAL_LEDInit(LED2);
    STM_EVAL_LEDInit(LED3);
    STM_EVAL_LEDInit(LED4);

    /* USARTx configured as follow:
          - BaudRate = 115200 baud
          - Word Length = 8 Bits
          - One Stop Bit
          - No parity
          - Hardware flow control disabled (RTS and CTS signals)
          - Receive and transmit enabled
    * /
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    STM_EVAL_COMInit(COM1, &USART_InitStructure);
    */
    /* Turn on leds available on STM3210X-EVAL **********************************/
    STM_EVAL_LEDOn(LED1);
    STM_EVAL_LEDOn(LED2);
    STM_EVAL_LEDOn(LED3);
    STM_EVAL_LEDOn(LED4);

    BSP_PWM_Init();

    CommTask(true);

    printf("\r\n STM32F10x Firmware Library compiled with FULL ASSERT function... \n\r");
    printf("...Run-time checking enabled  \n\r");

    /* Simulate wrong parameter passed to library function ---------------------*/
    /* To enable SPI1 clock, RCC_APB2PeriphClockCmd function must be used and
       not RCC_APB1PeriphClockCmd */
    RCC_APB1PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

    /* Some member of GPIOA_InitStructure structure are not initialized */
    GPIOA_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIOA_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    /* GPIOA_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; */
    GPIO_Init(GPIOA, &GPIOA_InitStructure);

    cpp_main();
    return 0;
}

#ifdef __cplusplus
}
#endif

#endif /* MAIN_C */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

