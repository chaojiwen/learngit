/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/main.cpp
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include <stdint.h>
#include "stm32glibc_rcc.h"
#include "stm32glibc_nvic.h"
#include "stm32glibc_systick.h"
#include "stm32glibc_gpio.h"
#include "stm32glibc_usart.h"
#include "stm32glibc_trace.h"
#include "stm32glibc_stream.h"
#include "main.h"

//	<<< Use Configuration Wizard in Context Menu >>>
//	<e>�������ڽ���
//	<i>����/�رմ��ڽ��չ���
#define USART_RECEIVE_EN		1
//	</e>
//
//	<e>ʹ��input/output�ı����������
//	<i>��ʹ��������Ļ����޷�ʹ���������ˡ�
#define	OUTPUT_EN				1
//	<o>�ı���������ͻ�������С
#define TEXT_OUT_BUFF_SIZE		8
//		<e>ʹ��input�ı�������
//		<i>ʹ��input�ı���������ռ��һ�����ڴ棬
//		<i>ע��input�������Ļ�������Ҫ�������ģ��һ��ʹ��
//		<i>������ﲻʹ��input����������ô����ģ����޷�ʹ�����뻺����
#define INPUT_EN				1
//		<o>�ı����������ջ�������С
#define TEXT_IN_BUFF_SIZE		8
//		</e>
//	</e>
//
//	<e>ʹ��printf�ı����
//	<i>ͨ��ϵͳ����printf�����ӡ������Ϣ
#define	DEBUG_OUTPUT_EN				1
//		<e>USART1ӳ��printf
//		<i>ʹ��USART1�ı������ӡ������Ϣ
//		<i>����ʹ��ITM Trace�����ӡ������Ϣ
#define DEBUG_OUTPUT_USART1_EN		0
//		</e>
//	</e>
//	<<< end of configuration section >>>




/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/* Private variables ---------------------------------------------------------*/
RCC_ClocksTypeDef 	MCU_Clocks;
//! ���ڣ�΢��
u32			 		nPeriod_MicroSeconds;
//! ��λ�����루�������Ϊ24�죩
vu32			 	nSystemTimingSystick = 0;
vs32				TimingDelay;
u8					LED_Pin0 = GPIO_Pin_0;

//!
namespace periph
{
    class USART1_PUTCHAR
    {
    public:
        static finline void Send(char ch)
        {
            COM1.PutChar(ch);
        }
    };
}

//!
#if(OUTPUT_EN != 0)
char TextOutBuffer[TEXT_OUT_BUFF_SIZE];
FIFO<char> textOutFIFO(TextOutBuffer, TEXT_OUT_BUFF_SIZE);
TextOutStream<periph::USART1_PUTCHAR> output(textOutFIFO);

//!
#if(INPUT_EN != 0)
char TextInBuffer[TEXT_IN_BUFF_SIZE];
FIFO<char> textInFIFO( TextInBuffer, TEXT_IN_BUFF_SIZE);
TextInStream<periph::USART1_PUTCHAR> input(textInFIFO, output);
#endif
#endif

/* Private functions ---------------------------------------------------------*/
/**
  * @brief  Description "������ʱ����"
  * @param  None
  * @retval None
  */


/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */
void Delay(vs32 nTime)
{
    TimingDelay = nTime;

    while(TimingDelay > 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
    if (TimingDelay > 0x00)
    {
        TimingDelay--;
    }
}
/**
  * @brief  Description "Debug ��ʼ��"
  * @param  None
  * @retval None
  */
void Debug_Configuration(void)
{
    using namespace mcucore;
    union mcu_info chip_info;
#if (DEBUG_OUTPUT_EN == 1)
#if (DEBUG_OUTPUT_USART1_EN == 1)

#else
    MCUTRACE.Init();
#endif
#endif
    MCUDBG.GetDebugMcuInfo(chip_info);
    printf("\r\n DebugMCUInfo\tDEV:%X,REV:%X.",
           chip_info.st.DEV_ID, chip_info.st.REV_ID);
    printf("\r\n DeviceInfo\tFlash:%dK,UID0:%X,UID1:%X,UID2:%X.\r\n",
           MCUINFO.F_SIZE,
           MCUINFO.U_ID0, MCUINFO.U_ID1, MCUINFO.U_ID2);
}

/**
  * @brief  Description "RCC ʱ�ӳ�ʼ��"
  * @param  None
  * @retval None
  */
void Clock_Configuration(void)
{
    using namespace mcucore;
    CLOCK.GetClocksFreq(MCU_Clocks);
    CLOCK.APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    CLOCK.APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    // ���ڣ�΢��
    nPeriod_MicroSeconds = 1000;
    SYSTICK.Config(MCU_Clocks.SYSCLK_Frequency / nPeriod_MicroSeconds, SYSTICK_CLKSRC_HCLK_Div8);
}

/**
  * @brief  Description "NVIC �ж����ȼ���ʼ��"
  * @param  None
  * @retval None
  */
void NVIC_Configuration(void)
{
    MCUSCB.SetPriorityGrouping(mcucore::GRP4_SUB4);
    MCUNVIC.IRQConfig(mcucore::USART1_IRQn);
}

/**
  * @brief  Description "USART ��ʼ��"
  * @param  None
  * @retval None
  */
void USART_Configuration(void)
{
    using namespace periph_c;
    IOPA.Config(GPIO_Pin_9, GPIO_MODE_AF_PP);
    IOPA.Config(GPIO_Pin_10, GPIO_MODE_IN_FLOATING);
    COM1.Config(9600);
    COM1.InterruptConfig(RXNEIT);
}


/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int cpp_env_init(char *buf, int size)
{
    if (buf[0] == 0)
    {
        LED_Pin0 = GPIO_Pin_6;
    }
    else
    {
        LED_Pin0 = GPIO_Pin_7;
    }

    // TODO: Configuration
    Clock_Configuration();
    USART_Configuration();
    Debug_Configuration();
    NVIC_Configuration();
    /* Retarget the C library printf function to the USARTx, can be USART1 or USART2
       depending on the EVAL board you are using ********************************/
    printf("\r\n %s", MESSAGE1);
    printf(" %s", MESSAGE2);
    printf(" %s\r\n", MESSAGE3);

	return 0;
}

char str[20];

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int cpp_main(void)
{
    /* Infinite loop */
    while (1)
    {
        output 	<< "\r\n������һ�����ʰ� :";
        output.Flush();
        input  	>> str;
        output	<< "\r\n������ĵ����ǣ�" << str << "\r\n";
        IOPF.ToggleBits(LED_Pin0);
        Delay(1000);
    }
    //	return 0;
}

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
ARMAPI PUTCHAR_PROTOTYPE
{
#if (DEBUG_OUTPUT_EN == 1)
#if (DEBUG_OUTPUT_USART1_EN == 1)
    COM1.PutChar(ch);
#else
    MCUTRACE.PutChar(ch);
#endif
#endif
    return ch;
}

/**
  * @brief  Description "���жϺ���"
  * @param  None
  * @retval None
  */
ARMAPI void SysTick_Handler(void)
{
    nSystemTimingSystick ++;
    TimingDelay_Decrement();
}

#if(USART_RECEIVE_EN!=0)
u8 USART_STATE = 0;
enum
{
    USART_Error = Bit(7)
};

/**
  * @brief  Description "This function handles PPP interrupt request."
  * @param  None
  * @retval None
  */
ARMAPI void USART1_IRQHandler(void)
{
    //	periph::usart::CUSART Usart1 = USART1_BASE;
    //	if(Usart1.Received())	//���յ�����
    if (COM1.Received())
    {
        textInFIFO << COM1.ReadByte();
    }
}
#endif


#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number */

    printf("\n\r Wrong parameter value detected on\r\n");
    printf("       file  %s\r\n", file);
    printf("       line  %d\r\n", line);

    /* Infinite loop */
    while (0)
    {
    }
}

#endif

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
